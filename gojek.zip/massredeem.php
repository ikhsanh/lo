<?php
error_reporting(0);
// Created By : Gidhan Bagus Algary
// Ijin mas Gidhan, saya Wahyu Arif P hapus dan tambah codingan dikit, creator tetap mas Gidhan
// Last Update : Wahyu Arif P : 20 Agustus 2019 22.07
echo "File Token: ";
$wahyuarifptoken = trim(fgets(STDIN));		
echo "Kode Promo: ";
$wahyuarifpkodepromo = trim(fgets(STDIN));		
$no = 0;

$file = file_get_contents("$wahyuarifptoken");
$data = explode("\n", str_replace("\r", "", $file));

for ($a = 0; $a < count($data); $a++) {
    $token   = $data[$a];
    $no++;

	$headers = array();
	$headers[] = 'Content-Type: application/json';
	$headers[] = 'X-AppVersion: 3.27.0';
	$headers[] = "X-Uniqueid: ac94e5d0e7f3f".rand(111,999);
	$headers[] = 'X-Location: -6.405821,106.064193';
	$headers[] = 'Authorization: Bearer '.$token;
	$postdata = '{"promo_code":"'. $wahyuarifpkodepromo .'"}';
	$claim = curl('https://api.gojekapi.com/go-promotions/v1/promotions/enrollments', $postdata, $headers);
	$claims = json_decode($claim[0]);
				if ($claims->success == true) {
					echo $no.". \e[0;42mSUKSES\e[0m | ".$token." | ".$claims->data->message."\n";
					} else {
					echo $no.". \e[0;41mGAGAL\e[0m | ".$token." | Pesan :  Gagal claim voucher, silahkan untuk mencoba manual :)\n";
				} 
			}

function curl($url, $fields = null, $headers = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        if ($fields !== null) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        }
        if ($headers !== null) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        $result   = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return array(
            $result,
            $httpcode
        );
	}
