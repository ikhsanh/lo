<?php
error_reporting(0);

#################################################
$token = "6927521c-984d-4096-9485-0b1950704be6";
$pin = "010400";
#################################################
echo "No? ";
$number = trim(fgets(STDIN));

$randValue = rand(100,200);

$secret = '83415d06-ec4e-11e6-a41b-6c40088ab51e';
$headers = array();
$headers[] = 'Content-Type: application/json';
$headers[] = 'X-AppVersion: 3.27.0';
$headers[] = "X-Uniqueid: ac94e5d0e7f3f".rand(111,999);
$headers[] = 'X-Location: -6.405821,106.064193';
$headers[] = 'Authorization: Bearer '.$token;

//echo "Processing send Rp. 1 to " . $number . "\n";
$getqrid = curl('https://api.gojekapi.com/wallet/qr-code?phone_number=%2B'.$number.'', null, $headers);

$jsqrid = json_decode($getqrid[0]);
$qrid = $jsqrid->data->qr_id;

$headertf = array();
$headertf[] = 'Content-Type: application/json';
$headertf[] = 'X-AppVersion: 3.27.0';
$headertf[] = "X-Uniqueid: ac94e5d0e7f3f".rand(111,999);
$headertf[] = 'X-Location: -6.405821,106.64193';
$headertf[] = 'Authorization: Bearer '.$token;
$headertf[] = 'pin:'.$pin.'';

$tf = curl('https://api.gojekapi.com/v2/fund/transfer', '{"amount":"'.$randValue.'","description":"Wahyu Arif P GO-Sender.","qr_id":"'.$qrid.'"}', $headertf);
$jstf = json_decode($tf[0]);
if($jstf->success == "1"){
    echo "Successful send Rp. " .$randValue. " to " .$number;
	} else {
        //print_r($jstf);
        echo "Failed.";
		}
								

function curl($url, $fields = null, $headers = null)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        if ($fields !== null) {
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        }
        if ($headers !== null) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        $result   = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return array(
            $result,
            $httpcode
        );
	}
